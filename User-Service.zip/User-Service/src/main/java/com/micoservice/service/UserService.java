package com.micoservice.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.micoservice.entity.User;

@Service
public class UserService {

	List<User> list = List.of(
			new User(123L,"srinivas","123456789"),
			new User(456L,"sri","789"),
			new User(789L,"vas","12345")
			);
	
	
	public User getUser(Long id)
	{
		return list.stream().filter(user -> user.getUserId().equals(id)).findAny().orElse(null);
	}
}
