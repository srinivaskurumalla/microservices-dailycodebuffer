package com.micoservice.service;

import java.util.List;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.micoservice.entity.Contact;
@Service
public class ContactService {

	List<Contact> list = List.of(
			new Contact(1L,"srinivas@gmail.com","123456789",123L),
			new Contact(11L,"srinivas123@gmail.com","1234789",123L),
			new Contact(1111L,"srinu123@gmail.com","129",123L),
			new Contact(2L,"sri@gmail.com","789",456L),
			new Contact(3L,"vas@gmail.com","12345",789L)
			);
	public List<Contact> getContactOfUser(Long userId)
	{
		return list.stream().filter(contact -> contact.getUserId().equals(userId)).collect(Collectors.toList());
	}
}
